# AquaFlow V1

App de hábito de beber água, bonito, com animações, histórico, estatísticas, armazenamento local e estrutura Android.

## Ver no navegador
Abra `web/index.html` com Live Server no VS Code.

## Gerar APK
O projeto Android está em `app/`. O workflow em `.github/workflows/build-apk.yml` gera o APK no GitHub Actions.

## Dados
Os registros são locais no navegador/WebView (`localStorage`). Não há login nem servidor.

## Notificações
No APK Android, o botão de teste e os lembretes usam uma ponte nativa. No Live Server, o navegador pode solicitar permissão para uma notificação de teste; lembretes persistentes são recurso do APK.
