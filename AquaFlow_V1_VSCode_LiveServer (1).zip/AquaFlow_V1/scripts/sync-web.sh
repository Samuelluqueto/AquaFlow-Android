#!/usr/bin/env bash
set -e
rm -rf app/src/main/assets
mkdir -p app/src/main/assets/css app/src/main/assets/js
cp web/index.html app/src/main/assets/index.html
cp web/css/styles.css app/src/main/assets/css/styles.css
cp web/js/app.js app/src/main/assets/js/app.js
